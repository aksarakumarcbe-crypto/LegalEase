import html
from datetime import date
import requests
import streamlit as st
from utils.document_formatter import format_docx, format_pdf, format_txt

st.set_page_config(page_title='LegalEase', page_icon='⚖️', layout='wide')
st.markdown('''<style>.title{text-align:center;font-size:42px;font-weight:700}.sub{text-align:center;color:#777}.preview{background:#111827;color:#f9fafb;padding:24px;border-radius:12px;max-height:650px;overflow-y:auto;white-space:pre-wrap;line-height:1.7;font-family:Georgia,serif}.warn{background:#fff7ed;padding:12px;border-left:4px solid #f97316}</style>''', unsafe_allow_html=True)
st.markdown('<div class="title">⚖️ LegalEase</div>', unsafe_allow_html=True)
st.markdown('<div class="sub">AI-Powered Legal Document Generator</div>', unsafe_allow_html=True)
st.markdown('<div class="warn"><b>Important:</b> LegalEase creates AI-assisted drafts for informational purposes. Review carefully and consult a qualified legal professional when appropriate.</div>', unsafe_allow_html=True)

if 'document' not in st.session_state: st.session_state.document=''
if 'logo' not in st.session_state: st.session_state.logo=None

with st.sidebar:
    st.header('Settings')
    backend=st.text_input('FastAPI Backend URL','http://127.0.0.1:8000').rstrip('/')
    logo=st.file_uploader('Optional company/logo image', type=['png','jpg','jpeg'])
    if logo:
        st.session_state.logo=logo.getvalue(); st.image(logo,width=150)
    if st.button('Check Backend'):
        try:
            r=requests.get(backend+'/health',timeout=5); st.success('Backend is running.') if r.ok else st.error(f'HTTP {r.status_code}')
        except requests.RequestException as e: st.error(str(e))

left,right=st.columns([1,1.25])
with left:
    st.subheader('Document Details')
    document_type=st.selectbox('Document Type',['Freelance Work Contract','Employment Contract','Non-Disclosure Agreement (NDA)','Residential Lease Agreement','Service Agreement','Business Partnership Agreement','General Agreement','Custom Legal Document'])
    if document_type=='Custom Legal Document': document_type=st.text_input('Enter custom document type','Software Licensing Agreement')
    parties=st.text_area('Parties Involved',placeholder='Jane Doe (Service Provider), TechNova Inc. (Client)',height=120)
    terms=st.text_area('Terms & Conditions',placeholder='Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice',height=220,help='Separate clauses with semicolons.')
    effective=st.date_input('Effective Date',date.today())
    jurisdiction=st.text_input('Jurisdiction / Governing Law (optional)',placeholder='Tamil Nadu, India')
    if st.button('Generate Document',type='primary',use_container_width=True):
        if not parties.strip() or not terms.strip(): st.error('Please enter parties and terms.')
        else:
            payload={'document_type':document_type,'parties':parties,'terms':terms,'effective_date':effective.isoformat(),'jurisdiction':jurisdiction or 'Not specified'}
            with st.spinner('Generating your legal document...'):
                try:
                    r=requests.post(backend+'/generate',json=payload,timeout=180)
                    if r.ok: st.session_state.document=r.json()['document']; st.success('Document generated successfully.')
                    else: st.error(r.json().get('detail',r.text))
                except requests.RequestException as e: st.error(f'Could not connect to FastAPI: {e}')
with right:
    st.subheader('Document Preview & Editor')
    if st.session_state.document:
        st.session_state.document=st.text_area('Click here to edit the generated document',st.session_state.document,height=520)
        st.markdown('<div class="preview">'+html.escape(st.session_state.document)+'</div>',unsafe_allow_html=True)
        st.markdown('#### Download')
        base=document_type.lower().replace(' ','_').replace('/','_').replace('(','').replace(')','')
        c1,c2,c3=st.columns(3)
        with c1: st.download_button('Download TXT',format_txt(st.session_state.document),f'{base}.txt','text/plain',use_container_width=True)
        with c2: st.download_button('Download DOCX',format_docx(st.session_state.document,document_type,st.session_state.logo),f'{base}.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document',use_container_width=True)
        with c3: st.download_button('Download PDF',format_pdf(st.session_state.document,document_type,st.session_state.logo),f'{base}.pdf','application/pdf',use_container_width=True)
    else: st.info('Enter the document details and click Generate Document.')
st.markdown('---'); st.caption('LegalEase | FastAPI + Streamlit + Gemini')
