import os, re
from io import BytesIO
from typing import Optional
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF

def sanitize_text(text: str) -> str:
    replacements={'\\u2018':"'",'\\u2019':"'",'\\u201c':'"','\\u201d':'"','\\u2013':'-','\\u2014':'-','\\u2026':'...','\\u00a0':' '}
    for a,b in replacements.items(): text=text.replace(a,b)
    return text.encode('latin-1', errors='replace').decode('latin-1')

def format_txt(text: str) -> bytes:
    return text.encode('utf-8')

def format_docx(text: str, doc_type: str, logo_bytes: Optional[bytes]=None) -> bytes:
    doc=Document()
    doc.styles['Normal'].font.name='Times New Roman'; doc.styles['Normal'].font.size=Pt(11)
    title=doc.add_paragraph(); title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=title.add_run(doc_type.upper()); r.bold=True; r.font.size=Pt(16); r.font.name='Times New Roman'
    if logo_bytes:
        p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        try: p.add_run().add_picture(BytesIO(logo_bytes), width=Inches(1.1))
        except Exception: pass
    for line in text.splitlines():
        s=line.strip()
        if not s: doc.add_paragraph(); continue
        if re.match(r'^\d+[.)]\s+', s) or (s.isupper() and len(s)<100):
            p=doc.add_paragraph(); rr=p.add_run(s); rr.bold=True
        elif s.startswith(('-', '*', '•')):
            doc.add_paragraph(s.lstrip('-*• ').strip(), style='List Bullet')
        else:
            p=doc.add_paragraph(s); p.paragraph_format.space_after=Pt(6)
    footer=doc.sections[0].footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fr=footer.add_run('LegalEase - AI-assisted legal document draft'); fr.font.size=Pt(8)
    out=BytesIO(); doc.save(out); return out.getvalue()

class LegalEasePDF(FPDF):
    def __init__(self, logo_path=None): super().__init__(); self.logo_path=logo_path
    def header(self):
        if self.logo_path and os.path.exists(self.logo_path):
            try: self.image(self.logo_path,x=92,y=8,w=25); self.ln(25); return
            except Exception: pass
        self.set_font('Helvetica','B',10); self.cell(0,8,'LegalEase',align='C'); self.ln(10)
    def footer(self):
        self.set_y(-15); self.set_font('Helvetica',size=8); self.cell(0,10,f'LegalEase - AI-assisted draft | Page {self.page_no()}',align='C')

def format_pdf(text: str, doc_type: str, logo_bytes: Optional[bytes]=None) -> bytes:
    temp=None
    if logo_bytes:
        temp='generated_logo.png'; open(temp,'wb').write(logo_bytes)
    pdf=LegalEasePDF(temp); pdf.set_auto_page_break(auto=True, margin=18); pdf.add_page()
    pdf.set_font('Helvetica','B',16); pdf.multi_cell(0,10,sanitize_text(doc_type.upper()),align='C'); pdf.ln(5)
    for line in text.splitlines():
        s=sanitize_text(line.strip())
        if not s: pdf.ln(3); continue
        bold=re.match(r'^\d+[.)]\s+',s) or (s.isupper() and len(s)<100)
        pdf.set_font('Helvetica','B' if bold else '',11 if bold else 10)
        pdf.multi_cell(0,7 if bold else 6,s.lstrip('-*• ').strip() if s.startswith(('-', '*', '•')) else s)
    data=bytes(pdf.output())
    if temp and os.path.exists(temp): os.remove(temp)
    return data
