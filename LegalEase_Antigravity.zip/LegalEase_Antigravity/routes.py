from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from ai_core.gemini_generator import GeminiDocumentGenerator

router = APIRouter()
generator = GeminiDocumentGenerator()

class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=100)
    parties: str = Field(..., min_length=2, max_length=5000)
    terms: str = Field(..., min_length=2, max_length=15000)
    effective_date: str = Field(..., min_length=2, max_length=100)
    jurisdiction: Optional[str] = Field(default='Not specified', max_length=200)

@router.post('/generate')
def generate_document(request: DocumentRequest):
    try:
        text = generator.generate_document(request.document_type, request.parties, request.terms, request.effective_date, request.jurisdiction or 'Not specified')
        return {'success': True, 'document': text}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
