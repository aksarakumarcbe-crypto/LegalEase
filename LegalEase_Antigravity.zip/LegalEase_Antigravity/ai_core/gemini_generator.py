import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        api_key = os.getenv('GEMINI_API_KEY')
        self.model_name = os.getenv('GEMINI_MODEL', 'gemini-1.5-pro')
        if not api_key:
            raise RuntimeError('GEMINI_API_KEY is missing. Add it to .env')
        self.client = genai.Client(api_key=api_key)

    def generate_document(self, document_type, parties, terms, effective_date, jurisdiction='Not specified'):
        term_list = [x.strip() for x in terms.replace('\\n',';').split(';') if x.strip()]
        formatted_terms = '\\n'.join('- ' + x for x in term_list)
        prompt = f'''You are the drafting engine for LegalEase, an AI-assisted legal document drafting application.

Create a professional LEGAL DOCUMENT DRAFT from the information below.

DOCUMENT TYPE: {document_type}
PARTIES: {parties}
EFFECTIVE DATE: {effective_date}
JURISDICTION: {jurisdiction}
TERMS / CONDITIONS:\n{formatted_terms}

Requirements:
1. Produce a complete, structured draft.
2. Use clear headings and numbered sections.
3. Include appropriate provisions such as purpose, definitions, obligations, payment, confidentiality, term/termination, representations, dispute/governing law, notices, and signatures when applicable.
4. Never invent material facts. Use [INSERT ...] placeholders for missing important information.
5. Keep the language professional and editable.
6. Do not claim guaranteed legal validity or compliance.
7. Return ONLY the document draft.

This is an AI-assisted draft and should be reviewed by a qualified legal professional when appropriate.'''
        response = self.client.models.generate_content(model=self.model_name, contents=prompt)
        text = getattr(response, 'text', None)
        if not text:
            raise RuntimeError('Gemini returned an empty response.')
        return text.strip()
