# LegalEase - Antigravity Ready

## Run

1. Open this folder in Antigravity.
2. Create and activate a virtual environment.
3. Run `pip install -r requirements.txt`.
4. Copy `.env.example` to `.env` and add `GEMINI_API_KEY`.
5. Terminal 1: `uvicorn main:app --reload --port 8000`
6. Terminal 2: `streamlit run app.py`
7. Open the Streamlit URL shown in the terminal.

The original specification describes a FastAPI backend, Streamlit frontend, Gemini document generation, editable preview, and TXT/DOCX/PDF export. This implementation provides those pieces. See the supplied project document for the original requirements.
